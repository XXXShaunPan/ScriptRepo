"""Quick Matching Tool package."""

from .config.settings import CURRENT_VERSION

__all__ = ["CURRENT_VERSION"]
__version__ = CURRENT_VERSION
