"""Google Drive integration."""

from __future__ import annotations

import io
from concurrent.futures import ThreadPoolExecutor

import aiohttp,asyncio
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload, MediaIoBaseUpload
from oauth2client.service_account import ServiceAccountCredentials

from quick_matching_tool.infra.google_auth import pick_client


def gen_drive_client(client: str = "random"):
    api_name = "drive"
    api_version = "v3"
    scopes = ["https://www.googleapis.com/auth/drive"]
    client_secret = pick_client(client)
    credentials = ServiceAccountCredentials.from_json_keyfile_dict(client_secret, scopes)
    return build(api_name, api_version, credentials=credentials, cache_discovery=False)


async def upload_file(
    drive_client,
    folder_id,
    file_name="",
    file_path="./",
    file_content=None,
):
    file_metadata = {"name": file_name, "parents": [folder_id]}

    if file_content is not None:
        media = MediaIoBaseUpload(io.BytesIO(file_content), mimetype="image/png", resumable=True)
    elif file_path.startswith("http://") or file_path.startswith("https://"):
        async with aiohttp.ClientSession() as session:
            async with session.get(file_path + file_name if file_name not in file_path else file_path) as response:
                response.raise_for_status()
                content = await response.read()
                media = MediaIoBaseUpload(io.BytesIO(content), mimetype="image/png", resumable=True)
    else:
        media = MediaFileUpload(file_path + file_name, resumable=True)

    loop = asyncio.get_running_loop()
    with ThreadPoolExecutor() as executor:
        file = await loop.run_in_executor(
            executor,
            lambda: drive_client.files().create(body=file_metadata, media_body=media, fields="id").execute(),
        )
    return file


def upload_file_with_executor(drive_client, folder_id, file_name="", file_content=None):
    file_metadata = {"name": file_name, "parents": [folder_id]}
    media = MediaIoBaseUpload(io.BytesIO(file_content), mimetype="image/png", resumable=True)
    return drive_client.files().create(body=file_metadata, media_body=media, fields="id").execute()


def download_file_from_google_drive(drive_client, file_id, output_path):
    request = drive_client.files().get_media(fileId=file_id)
    fh = io.BytesIO()
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while not done:
        _, done = downloader.next_chunk()
    with open(output_path, "wb") as f:
        f.write(fh.getvalue())


__all__ = [
    "gen_drive_client",
    "upload_file",
    "upload_file_with_executor",
    "download_file_from_google_drive",
]
