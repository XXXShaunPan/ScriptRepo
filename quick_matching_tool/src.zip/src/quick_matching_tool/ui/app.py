"""PyQt application entry."""

from __future__ import annotations

import logging
import os
import sys
import tempfile

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication,
    QCheckBox,
    QLabel,
    QHBoxLayout,
    QMessageBox,
    QMainWindow,
    QProgressDialog,
    QProgressBar,
    QPushButton,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from quick_matching_tool.config.logging import setup_logging
from quick_matching_tool.config.settings import CURRENT_VERSION, ENABLE_REMOTE_CODE, VERSION_CHECK_URL
from quick_matching_tool.ui.logging import LogHandler
from quick_matching_tool.ui.threads import (
    CodeSyncThread,
    GSheetLoadThread,
    ToolThread,
    UpdateCheckThread,
    UpdateDownloadThread,
)


class QuickMatchingApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Quick Matching Tool")
        screen_geometry = QApplication.desktop().availableGeometry()
        center_x = int((screen_geometry.width() - 1200) / 2)
        center_y = int((screen_geometry.height() - 1000) / 2)
        self.move(center_x, center_y)
        self.setGeometry(center_x, center_y, 1200, 1200)

        self.gsheet_url_info = []
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        self.apply_styles()

        splitter = QSplitter(Qt.Vertical)
        main_layout.addWidget(splitter)

        top_widget = QWidget()
        layout = QVBoxLayout(top_widget)

        usage_area = QTextEdit()
        usage_area.setReadOnly(True)
        usage_area.setMaximumHeight(300)
        usage_html = """
        <p style="font-size: 14pt; font-weight: bold;">使用说明：</p>
        <p style="margin-left: 20px;">
            1. 选择需要执行的批次号；<br>
            2. 点击"运行"按钮开始执行；<br>
            <span style="color: red; font-weight: bold;">3. 习惯性每次点击同步代码按钮 is a good habit.</span><br>
        </p>
        <p style="font-size: 14pt; font-weight: bold;">注意事项：</p>
        <p style="margin-left: 20px;">
            <span style="color: red; font-size: 14pt; font-weight: bold;">1. 运行过程中请勿关闭浏览器窗口，否则可能会导致运行失败；</span><br>
            2. 日志区域会显示详细的执行信息。
        </p>
        """
        usage_area.setHtml(usage_html)

        layout.addWidget(QLabel("使用说明："))
        layout.addWidget(usage_area)

        layout.addWidget(QLabel("选择批次号:"))
        self.batch_no_layout = QHBoxLayout()
        self.batch_no_checkboxes = []
        self.batch_no_loading_label = QLabel("正在加载批次号...")
        self.batch_no_progress = QProgressBar()
        self.batch_no_progress.setRange(0, 0)
        self.batch_no_progress.setTextVisible(False)
        self.batch_no_layout.addWidget(self.batch_no_loading_label)
        self.batch_no_layout.addWidget(self.batch_no_progress)

        self.batch_no_widget = QWidget()
        self.batch_no_widget.setLayout(self.batch_no_layout)
        layout.addWidget(self.batch_no_widget)

        button_layout = QHBoxLayout()
        self.run_button = QPushButton("运行")
        self.run_button.setObjectName("run_button")
        self.run_button.clicked.connect(self.run_tool)
        button_layout.addWidget(self.run_button)

        self.stop_button = QPushButton("中断")
        self.stop_button.setObjectName("stop_button")
        self.stop_button.clicked.connect(self.stop_tool)
        self.stop_button.setEnabled(False)
        button_layout.addWidget(self.stop_button)

        self.update_button = QPushButton(f"检查更新 (当前版本: v{CURRENT_VERSION})")
        self.update_button.setObjectName("update_button")
        self.update_button.clicked.connect(self.check_for_updates)
        button_layout.addWidget(self.update_button)

        if ENABLE_REMOTE_CODE:
            self.sync_code_button = QPushButton("同步代码")
            self.sync_code_button.setObjectName("sync_code_button")
            self.sync_code_button.clicked.connect(self.sync_remote_code)
            button_layout.addWidget(self.sync_code_button)

        button_widget = QWidget()
        button_widget.setLayout(button_layout)
        layout.addWidget(button_widget)

        splitter.addWidget(top_widget)

        log_widget = QWidget()
        log_layout = QVBoxLayout(log_widget)
        log_layout.addWidget(QLabel("输出日志："))

        self.log_area = QTextEdit()
        self.log_area.setObjectName("log_area")
        self.log_area.setReadOnly(True)
        self.log_area.setLineWrapMode(QTextEdit.NoWrap)
        log_layout.addWidget(self.log_area)

        splitter.addWidget(log_widget)
        splitter.setSizes([200, 300])

        self.log_handler = LogHandler()
        self.log_handler.new_log.connect(self.append_log)
        setup_logging(handler=self.log_handler)

        self.start_load_gsheet_url_info()

    def apply_styles(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #f5f7fb;
                color: #1f2937;
                font-family: "Helvetica Neue", Arial;
                font-size: 13px;
            }
            QLabel {
                color: #111827;
            }
            QTextEdit {
                background-color: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 10px;
                padding: 10px;
            }
            QTextEdit#log_area {
                background-color: #0b1220;
                border: 1px solid #111827;
                border-radius: 12px;
                padding: 12px;
                color: #e5e7eb;
                font-family: "Menlo", "Monaco", "Courier New";
                font-size: 12px;
            }
            QCheckBox {
                spacing: 8px;
                padding: 6px 4px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border-radius: 4px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
            }
            QCheckBox::indicator:checked {
                background: #2563eb;
                border: 1px solid #2563eb;
            }
            QPushButton {
                border: none;
                border-radius: 16px;
                padding: 8px 18px;
                color: #ffffff;
                font-weight: 600;
            }
            QPushButton#run_button {
                background-color: #10b981;
            }
            QPushButton#run_button:hover {
                background-color: #0ea371;
            }
            QPushButton#run_button:disabled {
                background-color: #9ca3af;
                color: #f3f4f6;
                border: 1px solid #94a3b8;
                opacity: 0.7;
            }
            QPushButton#stop_button {
                background-color: #ef4444;
            }
            QPushButton#stop_button:hover {
                background-color: #dc2626;
            }
            QPushButton#stop_button:disabled {
                background-color: #9ca3af;
                color: #f3f4f6;
                border: 1px solid #94a3b8;
                opacity: 0.7;
            }
            QPushButton#update_button {
                background-color: #3b82f6;
            }
            QPushButton#update_button:hover {
                background-color: #2563eb;
            }
            QPushButton#update_button:disabled {
                background-color: #9ca3af;
                color: #f3f4f6;
                border: 1px solid #94a3b8;
                opacity: 0.7;
            }
            QPushButton#sync_code_button {
                background-color: #8b5cf6;
            }
            QPushButton#sync_code_button:hover {
                background-color: #7c3aed;
            }
            QPushButton#sync_code_button:disabled {
                background-color: #9ca3af;
                color: #f3f4f6;
                border: 1px solid #94a3b8;
                opacity: 0.7;
            }
            QMessageBox QPushButton {
                background-color: #e5e7eb;
                color: #111827;
                border: 1px solid #d1d5db;
                border-radius: 10px;
                padding: 6px 16px;
                min-width: 84px;
                font-weight: 600;
            }
            QMessageBox QPushButton:hover {
                background-color: #dbe2ea;
            }
            QMessageBox QPushButton:pressed {
                background-color: #cbd5e1;
            }
            QPushButton:disabled {
                background-color: #9ca3af;
                color: #f3f4f6;
                border: 1px solid #94a3b8;
                opacity: 0.7;
            }
            QProgressBar {
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                background-color: #ffffff;
                height: 10px;
            }
            QProgressBar::chunk {
                border-radius: 8px;
                background-color: #3b82f6;
            }
            QSplitter::handle {
                background-color: #e5e7eb;
            }
        """)

    def start_load_gsheet_url_info(self):
        self.run_button.setEnabled(False)
        self.batch_no_loading_label.setText("正在加载批次号...")
        self.batch_no_progress.show()
        self.load_thread = GSheetLoadThread()
        self.load_thread.load_finished.connect(self.on_gsheet_loaded)
        self.load_thread.start()

    def on_gsheet_loaded(self, success: bool, message: str, data: list):
        self.batch_no_progress.hide()
        if success:
            self.gsheet_url_info = data
            self.refresh_batch_no_layout()
            self.run_button.setEnabled(True)
        else:
            self.batch_no_loading_label.setText("批次号加载失败")
            QMessageBox.warning(self, "提示", message)

    def refresh_batch_no_layout(self):
        while self.batch_no_layout.count():
            item = self.batch_no_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        self.batch_no_checkboxes = []
        all_batch_nos = [info["gsheet_name"] for info in self.gsheet_url_info]
        for batch_no in all_batch_nos:
            checkbox = QCheckBox(batch_no)
            self.batch_no_checkboxes.append(checkbox)
            self.batch_no_layout.addWidget(checkbox)

        if not self.batch_no_checkboxes:
            empty_label = QLabel("未加载到批次号")
            self.batch_no_layout.addWidget(empty_label)

    def append_log(self, message, level):
        color_map = {
            logging.DEBUG: "#FFFF00",
            logging.INFO: "#5eba5e",
            logging.WARNING: "#FFA500",
            logging.ERROR: "#FF0000",
            logging.CRITICAL: "#8B0000",
        }
        color = color_map.get(level, "#5eba5e")
        colored_message = (
            f'<div style="color: {color}; padding: 4px 0; '
            f'border-bottom: 1px solid rgba(148, 163, 184, 0.35); '
            f'line-height: 1.35;">{message}</div>')
        self.log_area.append(colored_message)
        self.log_area.verticalScrollBar().setValue(
            self.log_area.verticalScrollBar().maximum())

    def get_selected_batch_nos(self):
        selected_batch_nos = []
        for checkbox in self.batch_no_checkboxes:
            if checkbox.isChecked():
                selected_batch_nos.append(checkbox.text())
        if selected_batch_nos:
            return selected_batch_nos
        if self.batch_no_checkboxes:
            return [self.batch_no_checkboxes[0].text()]
        return []

    def run_tool(self):
        batch_nos = self.get_selected_batch_nos()
        if not batch_nos:
            QMessageBox.critical(self, "错误", "请至少选择一个批次号")
            return

        self.log_area.clear()
        logging.info("开始运行 Quick Matching Tool，批次号: %s", ", ".join(batch_nos))

        self.run_button.setEnabled(False)
        self.stop_button.setEnabled(True)

        source_gsheet_url_info = list(
            filter(lambda x: x["gsheet_name"] in batch_nos,
                   self.gsheet_url_info))
        self.tool_thread = ToolThread(source_gsheet_url_info,
                                      clear_cache=False)
        self.tool_thread.finished.connect(self.on_tool_finished)
        self.tool_thread.start()

    def stop_tool(self):
        if hasattr(self, "tool_thread") and self.tool_thread.isRunning():
            logging.info("正在中断操作...")
            self.tool_thread.stop()
            self.stop_button.setEnabled(False)

    def on_tool_finished(self, success, error_msg):
        self.run_button.setEnabled(True)
        self.stop_button.setEnabled(False)

        if success:
            logging.info("操作已完成")
            QMessageBox.information(self, "成功", "操作已完成")
        else:
            error_msg = f"运行时出错: {error_msg}"
            logging.error(error_msg)
            QMessageBox.critical(self, "错误", error_msg)

    def check_for_updates(self):
        self.update_button.setEnabled(False)
        self.update_button.setText("正在检查更新...")

        self.update_thread = UpdateCheckThread(VERSION_CHECK_URL,
                                               CURRENT_VERSION)
        self.update_thread.check_finished.connect(
            self.on_update_check_finished)
        self.update_thread.start()

    def on_update_check_finished(self, has_update: bool, latest_version: str,
                                 download_url: str, release_notes: str):
        self.update_button.setEnabled(True)
        self.update_button.setText(f"检查更新 (当前版本: v{CURRENT_VERSION})")

        if has_update:
            message = f"""
            <h3>发现新版本！</h3>
            <p><b>当前版本:</b> v{CURRENT_VERSION}</p>
            <p><b>最新版本:</b> v{latest_version}</p>
            <p><b>更新说明:</b></p>
            <p>{release_notes}</p>
            <p>是否立即下载更新？</p>
            """

            reply = QMessageBox.question(self, "发现新版本", message,
                                         QMessageBox.Ok | QMessageBox.Cancel,
                                         QMessageBox.Ok)

            if reply == QMessageBox.Ok and download_url:
                self.start_update_download(download_url, latest_version)
        else:
            if "检查失败" in release_notes:
                QMessageBox.warning(self, "检查更新", f"检查更新失败: {release_notes}")
            else:
                QMessageBox.information(self, "检查更新",
                                        f"当前已是最新版本 (v{CURRENT_VERSION})")

    def start_update_download(self, download_url: str, latest_version: str):
        self.update_button.setEnabled(False)
        self.update_button.setText("正在下载更新...")

        self.update_progress = QProgressDialog("正在下载更新...", "取消", 0, 100, self)
        self.update_progress.setWindowTitle("更新下载")
        self.update_progress.setWindowModality(Qt.WindowModal)
        self.update_progress.setValue(0)
        self.update_progress.show()

        self.update_download_thread = UpdateDownloadThread(
            download_url, latest_version)
        self.update_download_thread.progress.connect(self.on_update_progress)
        self.update_download_thread.finished.connect(
            self.on_update_download_finished)
        self.update_progress.canceled.connect(
            self.update_download_thread.cancel)
        self.update_download_thread.start()

    def on_update_progress(self, percent: int, downloaded: int, total: int):
        self.update_progress.setValue(percent)
        if total > 0:
            self.update_progress.setLabelText(
                f"正在下载更新... {percent}% ({downloaded // 1024} KB / {total // 1024} KB)"
            )

    def on_update_download_finished(self, success: bool, message: str,
                                    file_path: str):
        self.update_button.setEnabled(True)
        self.update_button.setText(f"检查更新 (当前版本: v{CURRENT_VERSION})")
        self.update_progress.close()

        if not success:
            QMessageBox.warning(self, "更新失败", message)
            return

        self.apply_update_and_restart(file_path)

    def apply_update_and_restart(self, new_file_path: str):
        exe_path = os.path.abspath(sys.argv[0])  # 获取exe文件的绝对路径
        exe_dir = os.path.dirname(exe_path)  # 获取exe文件的目录
        current_pid = os.getpid()  # 获取当前进程的pid

        if sys.platform.startswith("win"):
            script_path = os.path.join(tempfile.gettempdir(),
                                       "update_quick_matching.ps1")
            with open(script_path, "w", encoding="utf-8") as f:
                f.write(f"""
                Start-Sleep -Seconds 3
                Stop-Process -Id {current_pid} -Force -ErrorAction SilentlyContinue
                Remove-Item -Path "{exe_dir}" -Recurse -Force -ErrorAction SilentlyContinue
                Expand-Archive -Path "{new_file_path}" -DestinationPath "{os.path.dirname(exe_dir)}" -Force
                Start-Process -FilePath "{exe_path}"
                """)
            os.system(
                f'powershell -ExecutionPolicy Bypass -File "{script_path}"')
            sys.exit(0)
        else:
            QMessageBox.information(self, "更新完成", f"更新已下载到: {new_file_path}")

    def sync_remote_code(self):
        self.sync_code_button.setEnabled(False)
        self.sync_code_button.setText("同步中...")

        self.sync_thread = CodeSyncThread()
        self.sync_thread.sync_finished.connect(self.on_sync_code_finished)
        self.sync_thread.start()

    def on_sync_code_finished(self, success: bool, message: str):
        self.sync_code_button.setEnabled(True)
        self.sync_code_button.setText("同步代码")

        if success:
            QMessageBox.information(self, "同步完成", message)
        else:
            QMessageBox.warning(self, "同步失败", message)


def main() -> None:
    app = QApplication(sys.argv)
    window = QuickMatchingApp()
    window.show()
    sys.exit(app.exec_())
