"""Core services package."""
